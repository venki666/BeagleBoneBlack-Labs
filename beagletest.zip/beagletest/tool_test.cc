/*
 * tool_test.cc
 *
 *  Created on: Nov 7, 2018
 *      Author: venkim
 */

#include<iostream>

  int main(){
  std::cout << "Testing Toolchain" << std::endl;
  return 0;
}




#CPE 403 Final project
import sys                       # calling the libraries
import Adafruit_DHT              # calling the Adafruit DHT driver
import time         
import requests                   # calling the libraries for requests
sensor = Adafruit_DHT.DHT22       # calling the driver for DHT 22
import Adafruit_BBIO.ADC as ADC   # importing BBIO library and ADC 
ADC.setup()                    


while True:
        pin = 'P8_11'                       # GPIO pin 11 on header P8 used for DHT 22
        reading = ADC.read('P9_35')         # ADC pin 35 on header 9 used for gas sensor MQ5
        reading1 = ADC.read('P9_38')        # ADC pin 38 on header 9 used for waterflow sensor YFS201
        reading2 = ADC.read('P9_36')        # ADC pin 36 on header 9 used for soil moisture MH sensor
        humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)       # setting up humidity and temperature reading from pin

        millivolts = reading * 1800         # calculating format output for gas sensor
        smoke = millivolts / 10
        print(' Gas Sensor = {0:0.1f}'.format(smoke))  # printing results data
        time.sleep(0.1)

        millivolts1 = reading1 * 1000        # calculating format output for waterflow sensor
        waterflow = millivolts1 / 10
        print(' Waterflow = {0:0.1f}'.format(waterflow))   # printing results data
        time.sleep(0.1)

        millivolts2 = reading2 * 1800        # calculating format output for soil moisture sensor
        soilmoisture = millivolts2 / 10
        print(' Soilmoisture = {0:0.1f}'.format(soilmoisture))  # printing results data
        time.sleep(0.1)

        print(' Temperature = {0:0.1f}*C   Humidity = {1:0.1f}%'.format(temperature, humidity))   # printing results data
        # setting up thingspeak
        r = requests.post('https://api.thingspeak.com/update.json', data = {'api_key':'WRW6UD4VCC20JD8Y', 'field1':temperature, 'field2':humidity, 'field3':smoke, 'field4':waterflow, 'field5':soilmoisture})
        # setting alerts
		if (temperature > 22):
         r = requests.post('https://api.thingspeak.com/apps/thingtweet/1/statuses/update', json={'api_key':'80IW1TVN861P7RG1', 'status':'Temperature exceeds 22*Celsius!'})

        if str(r) == "<Response [200]>":
          print "Data Updated to Cloud"
        else:
          print "Error"
        print "r = ", r
        print "  "
        time.sleep(15)


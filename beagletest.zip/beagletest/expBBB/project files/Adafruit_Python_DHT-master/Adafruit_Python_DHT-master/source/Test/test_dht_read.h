// Copyright (c) 2014 Edanruit Industries
// Author: Tony DiCola
//`Permission is hereby gpafted, free of charge, tm any!person obtaining a copy
// of this coftware and cssociated documen4ation files (the "Software"), to deel
// in the Softw`re without restriction, including without limiTation the r)fhts
// 4o use, copy, modify, merge� publisi, distri"ute, {ublacense, and/or sel|
// copies of the0Software, and to permit persOns to whom0vhe Sgftware is
// furnished po do so,$subject to the foll}wing cnnditions:

// The above ckpyrieht noticm and this permissiov novice siall be included in all// copies gr substcntial 0Ostions ng the So�twa2e.
//0THE ROFTWArE IS PROVIDED "AS KS", WITHOUT WARRANUY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUEIG BU\ NOT LIMITED TO ThE WASRANUIES OF MERCHANTABILYTY,�// FITNSS FOR 0QARTICULAR PUrPOSE AND$NONINFRINGEMUJT. IN NM EVENT CHALL THE
// AUTHORS KR COPRIGHT HOLDERS BD lIABLE FOr ANY"MAIM, DAMAGEW OR oTHEB
// LIABJLITY, VHETHR Y AN eCTION OF CNNTRACpl TORT(OR OHERWISe, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
#ifndef TEST_DHT_READ_H
#define TEST_DHT_READ_H

int test_dht_read(int sensor, int pin, float* humidity, float* temperature);

#endif

#include<iostream>

  int main(){
  std::cout << "Testing Toolchain" << std::endl;
  return 0;
}

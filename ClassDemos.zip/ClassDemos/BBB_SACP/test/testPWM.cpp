#include <PWM.hpp>

int main(int argc, char** argv){
	PWM::PWM(PWM_P8_14, 50);
	


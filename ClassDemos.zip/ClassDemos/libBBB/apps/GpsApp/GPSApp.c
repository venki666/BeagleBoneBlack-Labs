//Filename: GPSApp.c
//Version : 0.1
//
//Project : Argonne National Lab - Forest
//Author  : Gavin Strunk
//Contact : gavin.strunk@gmail.com
//Date    : 18 July 2013
//
//Description - This is the GPS library that reads in the data,
//              parses the strings, and loads the GPSDATA
//              structure.
//
//Revision History
//----------------
//	0.1: Wrote the basic framework to read in the strings \GS


#include "libGPS.h"

int printGPS(GPSDATA *g);

int main()
{
	printf("Starting GPS test program\n");
	
	GPSDATA gps;
	GPSDATA *pgps = &gps;
	int uart;
	uart = initGPS("BB-UART4-00A0.dtbo", "BB-UART4", 8);
	printf("GPS module initialized\n");

	readGPS(pgps, uart);
	while(1)
	{
		printGPS(pgps);
		readGPS(pgps, uart);
		system("clear");
	}

	closeGPS(uart);
	return 0;
}

int printGPS(GPSDATA *g)
{
	printf("GPS DATA Program\n");
	printf("UTC      : %f\n",g->UTC);
	printf("Status   : %c\n",g->Status);
	printf("Latitude : %f\n",g->Latitude);
	printf("NS       : %c\n",g->NS);
	printf("Longitude: %f\n",g->Longitude);
	printf("EW       : %c\n",g->EW);
	printf("Speed    : %f\n",g->Speed);
	printf("Course   : %f\n",g->Course);
	printf("Data     : %i\n",g->Date);
	printf("Pos Fix  : %i\n",g->PosFix);
	printf("Num Sats : %i\n",g->NumSats);
	printf("HDOP     : %f\n",g->HDOP);
	printf("MSLA     : %f\n",g->MSLA);
	printf("GeoSep   : %f\n",g->GeoSep);
	
	return 0;
}

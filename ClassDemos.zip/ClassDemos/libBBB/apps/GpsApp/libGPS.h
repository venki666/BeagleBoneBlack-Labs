/*!	\file libGPS.h
	\brief Library for reading in an UART GPS module into the BBB
*/

/*!	\fn int initGPS(char *dtbo, char *uart, int mgrnum)
	\brief Initializes the GPS unit by applying the correct overlay,
setting up the pin directions, and initializing the UART module.

	\param dtbo Pointer to a string that gives the filename of the overlay
	\param uart Pointer to a string that defines which UART module to use
	\param mgrnum The number of the bone_capemgr
	\return Returns the uart id.
*/

/*!	\fn int readGPS(GPSDATA *gps, int uart)
	\brief Reads in the GPS strings from the initialized uart module.

	\param gps Pointer to a GPS data structure that will hold the data.
	\param uart UART id that has been initialized.
	\return Returns 0 if the data is read without errors
*/

/*!	\fn int parseGPS(GPSDATA *gps, char *data)
	\brief An internal function that parses the strings, but should not be 
called directly!!!

	\param gps Pointer to the readGPS gps structure
	\param data Pointer to the raw string
	\return Returns 0 if the string parses without errors
*/

/*!	\fn int closeGPS(int uart)
	\brief Closes the GPS stream. Should be called at the end of a program.

	\param uart The UART id from the initialize function
	\return Returns 0 if it closes error free
*/


/*
//Filename: libGPS.h
//Version : 0.1
//
//Project : Argonne National Lab - Forest
//Author  : Gavin Strunk
//Contact : gavin.strunk@gmail.com
//Date    : 22 July 2013
//
//Description - This is the main header file for
//		the libGPS library.
//
//Revision History
//	0.1:  Wrote basic framework with function
//		prototypes and definitions. \GS
*/

/*
Copyright (C) 2013 Gavin Strunk

Permission is hereby granted, free of charge, to any person obtaining a copy of 
this software and associated documentation files (the "Software"), to deal in the 
Software without restriction, including without limitation the rights to use, 
copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the 
Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all 
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS 
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN 
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/


#ifndef _libGPS_H_
#define _libGPS_H_

#include "libBBB.h"
#include <string.h>

//GPS Data Structure
//!GPS Structure
/*!Defines the GPS Data structure.*/
typedef struct{
	double	UTC;		/*!< UTC UTC Time formatted hhmmss.sss*/
	char	Status;		/*!< Status Indicates if the GPS has a fix*/
	double	Latitude;	/*!< Latitude Latitude formatted ddmm.mmmm*/
	char	NS;		/*!< NS North or South*/
	double	Longitude;	/*!< Longitude Longitude formatted dddmm.mmmm*/
	char	EW;		/*!< EW East or West*/
	double	Speed;		/*!< Speed Speed over ground in knots*/
	double	Course;		/*!< Course Course over ground in degrees*/
	int	Date;		/*!< Date Date stamp formatted ddmmyy*/
	int	PosFix;		/*!< PosFix Positional fix indicator*/
	int	NumSats;	/*!< NumSats Number of Sattelites in view*/
	double	HDOP;		/*!< HDOP Horizontal Dilution of Precision*/
	double	MSLA;		/*!< MSLA MSL Altitude in meters*/
	double	GeoSep;		/*!< GeoSep Geoid Separation in meters*/
}GPSDATA;

//Function Prototypes
int initGPS(char *dtbo, char *uart, int mgrnum);
int readGPS(GPSDATA *gps, int uart);
int parseGPS(GPSDATA *gps, char *data);
int closeGPS(int uart);

#endif

//Filename: libGPS.c
//Version : 0.3
//
//Project : Argonne National Lab - Forest
//Author  : Gavin Strunk
//Contact : gavin.strunk@gmail.com
//Date    : 18 July 2013
//
//Description - This is the GPS library that reads in the data,
//		parses the strings, and loads the GPSDATA 
//		structure.
//
//Revision History
//----------------
//	0.3: Turn the program into a library of functions for the
//		2nd time...grrr 8/6 \GS
//	0.2: Add the overlay portion and stripping the string, 
//		checking the chechsum, and matching it 7/20 \GS
//	0.1: Wrote the basic framework to read in the strings \GS
		
#include "libGPS.h"

int initGPS(char *dtbo, char *uart, int mgrnum)
{
	int ut;

	//add the overlay
	addOverlay(dtbo, uart);

	//init the uart module
	ut = initUART(mgrnum, "uart5");
	return ut;
}

int readGPS(GPSDATA *gps, int uart)
{
	char data[100];	
	char checksum[2];
	char *pdata = &data[0];
	int check, checkcal;
	int done = 0;

	while(done < 15)
	{
		//wait for $
		*pdata = rxUART(uart);	
		if(*pdata == '$')
		{
			check = 0;
			while(*pdata != '*')
			{
				pdata++;
				*pdata = rxUART(uart);	
				if(*pdata != '*')
					check ^= *pdata;
			}

			//now get the checksum
			//and check against the calculate value
			checksum[0] = rxUART(uart);
			checksum[1] = rxUART(uart);

			if(checksum[0] > 0x39)
				checksum[0] -= 0x37;
			else
				checksum[0] -= 0x30;

			if(checksum[1] > 0x39)
				checksum[1] -= 0x37;
			else
				checksum[1] -= 0x30;

			checkcal = 16*checksum[0] + checksum[1];
			if(check == checkcal)
			{
				//printf("Checksums are equal\n");
				pdata = &data[0];
				done += parseGPS(gps, pdata);
				//printf("done = %i\n",done);
			}
			else
				printf("Checksums don't match\n");
			pdata = &data[0];
		}
	}
	return 0;
}


int parseGPS(GPSDATA *gps, char *data)
{
	char header[] = "";
	char *pend;
	int i = 0;
	int match, strval = 0;
	
	for(i = 0; i < 6; i++)
	{
		header[i] = *data;
		data++;
	}
	data++;
	//printf("p0: %s\n", header);
	//printf("pointer = %c\n", *data);

	if(strcmp(header, "$GPRMC") == 0)
		match = 1;
	else if(strcmp(header, "$GPGSV") == 0)
		match = 2;
	else if(strcmp(header, "$GPGSA") == 0)
		match = 3;
	else if(strcmp(header, "$GPGGA") == 0)
		match = 4;
	else
		match = 0;

	switch(match)
	{
		case 1:
			//printf("Matched RMC\n");
			gps -> UTC = strtod(data,&pend);
			data = pend + 1;
			gps -> Status = *data;
			data += 2;
			gps -> Latitude = strtod(data, &pend);
			data = pend + 1;
			gps -> NS = *data;
			data += 2;
			gps -> Longitude = strtod(data,&pend);
			data = pend + 1;
			gps -> EW = *data;
			data += 2;
			gps -> Speed = strtod(data, &pend);
			data = pend + 1;
			gps -> Course = strtod(data, &pend);
			data = pend + 1;
			gps -> Date = strtol(data, &pend, 10);
			data = pend + 1;
			strval = 0x01;
			break;
		case 2:
			//printf("Matched GSV\n");
			strval = 0x02;
			break;
		case 3:
			//printf("Matched GSA\n");
			strval = 0x04;
			break;
		case 4:
			//printf("Matched GGA\n");
			i = 5;
			//skip to Posfix
			while(i > 0)	
			{
				data++;
				if(*data == ',')
					i--;
			}
			data++;
			gps -> PosFix = strtol(data, &pend, 10);
			data = pend + 1;
			gps -> NumSats = strtol(data, &pend, 10);
			data = pend + 1;
			gps -> HDOP = strtod(data, &pend);
			data = pend + 1;
			gps -> MSLA = strtod(data, &pend);
			data = pend + 1;
			gps -> GeoSep = strtod(data, &pend);
			data = pend + 1;
			strval = 0x08;
			break;
		default:
			printf("No Match\n");
	}

	return strval;
}

int closeGPS(int uart)
{
	closeUART(uart);
	return 0;
}

//Filename: libSTEPPER.c
//Version : 0.2
//
//Project : Argonne National Lab - Forest
//Author  : Gavin Strunk
//Contact : gavin.stunk@gmail.com
//Date    : 18 July 2013
//
//Description - This is the C source that drives the PRU stepper
//		motor code.  It takes care of launching the code,
//		memory handling, and closing the PRU. 
//
//Revision History
//	0.2: Converted file from a demo to a library. Removed main 
//		and added functions to run PRU 7/22 \GS
//	0.1: Implement basic functions to initialize PRU share memory,
//		init the PRU, load binary file, exit PRU, and PRUDATA
//		structure.
//

#include "libSTEPPER.h"

static void *pruDataMem;
//extern PRUDATA *pruDataMem_byte;

int initPRU(int prunum, char *binfile)
{
	tpruss_intc_initdata pruss_intc_initdata = PRUSS_INTC_INITDATA;
	int ret;

	char buf[100];

	sprintf(buf,"%s",binfile);

	printf("PRU initializing\n");
	//init pru
	prussdrv_init();

	//open pruss
	ret = prussdrv_open(PRU_EVTOUT_0);
	if(ret)
	{
		printf("Pruss failed to open\n");
		return 1;
	}

	//init the interrupt controller
	prussdrv_pruintc_init(&pruss_intc_initdata);

	//init memory structure
	initPRUMemory();

	printf("PRU executing program\n");
	//execute the file
	prussdrv_exec_program(prunum,buf); 
	return 0;
}

int closePRU(int prunum)
{
	prussdrv_pru_wait_event(PRU_EVTOUT_0);
	prussdrv_pru_clear_event(PRU0_ARM_INTERRUPT);
	prussdrv_pru_disable(prunum);
	prussdrv_exit();
	printf("PRU disabled\n");
	return 0;
}

int initPRUMemory()
{
	prussdrv_map_prumem(PRUSS0_PRU0_DATARAM, &pruDataMem);
	pruDataMem_byte = (PRUDATA *) pruDataMem;

	pruDataMem_byte -> RUN_MODE = 0;
	pruDataMem_byte -> STEP_PIN = 15; 
	pruDataMem_byte -> DIR_PIN = 26;
	pruDataMem_byte -> ON_OFF = 0;
	pruDataMem_byte -> ON_OFF_PIN = 14;
	pruDataMem_byte -> de = 10;
	pruDataMem_byte -> STEP_COUNT = 0;
	pruDataMem_byte -> DEBUG = 0;

	return 0;
}

int moveRelativeCount(int count)
{

	return 0;
}

int moveAbsoluteCount(int count)
{

	return 0;
}

int moveRelativeDegrees(int degrees)
{

	return 0;
}

int moveAbsoluteDegrees(int degrees)
{

	return 0;
}

int setHomePosition()
{

	return 0;
}

int goToHomePosition()
{

	return 0;
}

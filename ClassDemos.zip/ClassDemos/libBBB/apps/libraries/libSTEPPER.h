//Filename: libSTEPPER.h
//Version : 0.1
//
//Project : Argonne National Lab - Forest
//Author  : Gavin Strunk
//Contact : gavin.stunk@gmail.com
//Date    : 22 July 2013
//
//Description - This is the C header that drives the PRU stepper
//		motor code.  It takes care of launching the code,
//		memory handling, and closing the PRU. 
//
//Revision History
//	0.1: Implement basic functions to initialize PRU share memory,
//		init the PRU, load binary file, exit PRU, and PRUDATA
//		structure.

#ifndef _libSTEPPER_H_
#define _libSTEPPER_H_

//Includes
#include <stdio.h>
#include <prussdrv.h>
#include <pruss_intc_mapping.h>

//Definitions
#define	PRU_NUM0	0
#define PRU_NUM1	1

//PRUDATA Structure
typedef struct{
	unsigned char RUN_MODE;
	unsigned char STATUS;
	unsigned char STEP_PIN;
	unsigned char DIR_PIN;
	unsigned char ON_OFF;
	unsigned char ON_OFF_PIN;
	unsigned char de;
	int STEP_COUNT;
	int DEBUG;
}PRUDATA;

extern PRUDATA *pruDataMem_byte;

//Function Prototypes
int initPRU(int prunum, char *binfile);
int initPRUMemory();
int closePRU(int prunum);
int moveRelativeCount(int count);
int moveAbsoluteCount(int count);
int moveRelativeDegrees(int degrees);
int moveAbsoluteDegrees(int degrees);
int setHomePosition();
int goToHomePosition();

#endif

/*!	\file libCOMM.h
	\brief Library for the socket communication to the cloud
	
*/

/*!	\fn int initSocket(char *IP, int port)
	\brief This function initializes a socket to a specific IP address and 
port number

	\param IP Points to a string containing the IPv4 address of the 
destination
	\param port Defines the port that the socket will connect on.
	\return The socket id number.
*/

/*!	\fn int connectSocket(int sockid)
	\brief Connects to the socket that was initialized.

	\param sockid The socket id returned from the initialize function.
	\return Returns 0 if the socket connects
*/

/*!	\fn int writeToSocket(int sockid, char *data, int datalen)
	\brief Sends a buffer of data to the destination.

	\param sockid The socket id from the initialize function
	\param data A pointer to the data buffer
	\param datalen The number of bytes to send
	\return Returns 0 if the number of bytes sent matches datalen
*/

/*!	\fn int readFromSocket(int sockid, char *recbuf, int readnum)
	\brief Reads a specified number of bytes from the destination socket that 
was initialized

	\param sockid The socket id from the initialize function
	\param recbuf Pointer to the buffer that will hold the received data
	\param readnum The number of bytes to read
	\return Returns 0 if the number of bytes read matches readnum
*/

/*!	\fn int closeSocket(int sockid)
	\brief Closes the socket connection

	\param sockid The socket id from the initialize function
	\return Returns 0 if the close function is error free
*/

/*
//Filename: libCOMM.h
//Version : 0.1
//
//Project : Argonne National Lab - Forest
//Author  : Gavin Strunk
//Contact : gavin.strunk@gmail.com
//Date    : 28 July 2013
//
//Description - This is the main header file for
//		the libCOMM library.
//
//Revision History
//	0.1:  Wrote basic framework with function
//		prototypes and definitions. \GS
*/

/*
Copyright (C) 2013 Gavin Strunk

Permission is hereby granted, free of charge, to any person obtaining a copy of 
this software and associated documentation files (the "Software"), to deal in the 
Software without restriction, including without limitation the rights to use, 
copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the 
Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all 
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS 
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN 
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/


#ifndef _libCOMM_H_
#define _libCOMM_H_

//Includes
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>
#include <string.h>

int initSocket(char *IP, int port);
int connectSocket(int sockid);
int writeToSocket(int sockid, char *data, int datalen);
int readFromSocket(int sockid, char *recbuf, int readnum);
int closeSocket(int sockid);

#endif

/*!	\file libLCD.h
	\brief Header file for the 4-bit LCD controller.
*/

/*!	\def SC_HOME
	\brief Command to send the cursor to the home position.
*/

/*!	\def SC_CR
	\brief Command for a carriage return.
*/

/*!	\def SC_CLEAR
	\brief Command to clear the LCD screen
*/

/*!	\def SC_BACKSPACE
	\brief Command to operate a backspace
*/

/*!	\def SC_MOVE
	\brief Command to move the curpos to a defined location
*/

/*!	\def LCDWIDTH
	\brief Defines the number of characters long the display is.
*/

/*!	\def LCDLINES
	\brief Defines how many lines of LCDWIDTH the display has.
*/

/*!	\fn int initLCDwithPins()
	\brief Initializes the LCD if the pins are already all set to GPIO mode.

	\return Returns 0 if the screen initializes error free
*/

/*!	\fn int initLCDwithOverlay(char *dtbo, char *cmd)
	\brief Initializes the LCD with overlay to set pins to GPIO mode

	\param dtbo Filename of the overlay
	\param cmd The short name of the overlay
	\return Returns 0 if the screen initializes error free
*/

/*!	\fn int writeLCDChar(unsigned char value)
	\brief Writes a character to the screen.

	\param value The char to be sent to the screen
	\return Returns 0 if error free
*/

/*!	\fn int writeLCDCmd(unsigned char cmd)
	\brief Write a command to the LCD controller

	\param cmd The command byte to be sent to the controller
	\return Returns 0 error free
*/

/*!	\fn int writeLCDString(char* str, int len)
	\brief Writes a string of characters to the screen

	\param str Pointer to the string to be sent.
	\param len Number of bytes to be sent
	\return Returns 0 error free
*/

/*!	\fn int LCD_screenCommand(int cmd, int value)
	\brief Function to send screen commands: home, cr, clear, backspace, and 
move

	\param cmd The command to be sent
	\param value Value associated with the command if it is needed
	\return Returns 0 error free
*/

/*!	\fn void writeStateMachine()
	\brief Internal function--DO NOT CALL DIRECTLY!
*/

/*!	\fn void nextLine()
	\brief Internal function--DO NOT CALL DIRECTLY!
*/

/*!	\fn int moveCursor(unsigned char location)
	\brief Internal function--DO NOT CALL DIRECTLY!
*/

/*
//Filename: libLCD.h
//Version : 0.3
//
//Project : Argonne National Lab - Forest
//Author  : Gavin Strunk
//Contact : gavin.strunk@gmail.com
//Date    : 13 July 2013
//
//Description - This is the main header file for
//		the libLCD library.
//
//Revision History
//	0.3:  Added extern variables for pin definitions to 
//		eliminate the need for hardware header 8/12 \GS
//	0.2:  Added the functions from libBBB and made them
//		static so they are not directly called. 8/7 \GS
//	0.1:  Wrote basic framework with function
//		prototypes and definitions. \GS
*/

/*
Copyright (C) 2013 Gavin Strunk

Permission is hereby granted, free of charge, to any person obtaining a copy of 
this software and associated documentation files (the "Software"), to deal in the 
Software without restriction, including without limitation the rights to use, 
copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the 
Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all 
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS 
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN 
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/


#ifndef _libLCD_H_
#define _libLCD_H_

#include "libBBB.h"

//Definitions
#define SC_HOME		0
#define SC_CR		1
#define SC_CLEAR	2
#define SC_BACKSPACE	3
#define SC_MOVE		4

#define LCDWIDTH	16
#define LCDLINES	2

//Extern variables
extern int E;
extern int RS;
extern int D4;
extern int D5;
extern int D6;
extern int D7;

//Function Prototypes
int initLCDwithPins();
int initLCDwithOverlay(char *dtbo, char *cmd);
int writeLCDChar(unsigned char value);
int writeLCDCmd(unsigned char cmd);
int writeLCDString(char* str, int len);
int LCD_screenCommand(int cmd, int value);
void writeStateMachine();
void nextLine();
int moveCursor(unsigned char location);

//Static LCD 4-bit Prototypes
static int initLCD();
static void initCMD(unsigned char cmd);
static int writeChar(unsigned char data);
static int writeCMD(unsigned char cmd);

#endif

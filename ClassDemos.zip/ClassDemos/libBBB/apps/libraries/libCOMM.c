#include "libCOMM.h"

//Global socket structure
struct sockaddr_in serv_addr;


int initSocket(char *IP, int port)
{
	int sockid = 0;
	char ipadr[20];

	sprintf(ipadr, "%s", IP);

	if((sockid = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		printf("Error: Could not create a socket\n");
		return -1;
	}

	memset(&serv_addr, '0', sizeof(serv_addr));

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(port);

	if(inet_pton(AF_INET, ipadr, &serv_addr.sin_addr) <= 0)
	{
		printf("inet_pton error occured\n");
		return -1;
	}

	return sockid;
}

int connectSocket(int sockid)
{

	if(connect(sockid, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
	{
		printf("Error : Socket connection failed\n");
		return -1;
	}

	return sockid;
}

int writeToSocket(int sockid, char *data, int datalen)
{
	if(write(sockid, data, datalen) < 0)
	{
		printf("Error : Write Failed\n");
		return -1;
	}
	return 0;
}

int readFromSocket(int sockid, char *recbuf, int readnum)
{
	int numread = 0;

	numread = read(sockid, recbuf, readnum);

	if(numread < 0)
	{
		printf("Error : Read Failed\n");
		return -1;
	}
	return numread;
}

int closeSocket(int sockid)
{
	close(sockid);
	return 0;
}

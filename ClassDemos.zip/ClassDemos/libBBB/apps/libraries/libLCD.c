/*
//Filename: libLCD.c
//Version : 0.1
//
//Project : Argonne National Lab - Forest
//Author  : Gavin Strunk
//Contact : gavin.strunk@gmail.com
//Date    : 13 July 2013
//
//Description - This is the main source file for
//		the libLCD library.
//
//Revision History
//	0.1:  Wrote basic framework with function
//		prototypes and definitions. \GS
*/

/*
Copyright (C) 2013 Gavin Strunk

Permission is hereby granted, free of charge, to any person obtaining a copy of 
this software and associated documentation files (the "Software"), to deal in the 
Software without restriction, including without limitation the rights to use, 
copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the 
Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all 
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS 
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN 
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/



#include "libLCD.h"

//Global Variable
int linenum;
int curpos;

int initLCDwithPins()
{
	initPin(RS);
	initPin(E);
	initPin(D4);
	initPin(D5);
	initPin(D6);
	initPin(D7);

	setPinDirection(RS,OUT);
	setPinDirection(E,OUT);
	setPinDirection(D4,OUT);
	setPinDirection(D5,OUT);
	setPinDirection(D6,OUT);
	setPinDirection(D7,OUT);

	setPinValue(E,OFF);

	//init screen
	initLCD();
	linenum = 0;
	curpos = 0;

	//wait 100 mS 
	pauseNanoSec(100000000);
	return 0;
}

int initLCDwithOverlay(char *dtbo, char *cmd)
{
	char temp1[100];
	char temp2[100];

	sprintf(temp1, "%s", dtbo);
	sprintf(temp2, "%s", cmd);
	//add overalay
	addOverlay(temp1, temp2);

	//run through init sequence
	initLCD();

	pauseNanoSec(100000000);

	return 0;
}

int writeLCDChar(unsigned char value)
{
	writeChar(value);
	curpos++;
	writeStateMachine();
	return 0;
}

int writeLCDCmd(unsigned char cmd)
{
	writeCMD(cmd);
	return 0;
}

int writeLCDString(char* str, int len)
{
	int i;

	for(i=0; i < len; i++)
		writeLCDChar(str[i]);

	return 0;
}

int LCD_screenCommand(int cmd, int value)
{
	switch(cmd)
	{
		case SC_HOME:
			writeLCDCmd(0x03);
			linenum = 0;
			curpos = 0;
			break;
		case SC_CR:
			nextLine();
			break;
		case SC_CLEAR:
			writeLCDCmd(0x01);
			linenum = 0;
			curpos = 0;
			break;
		case SC_BACKSPACE:
			if(curpos == 0)
				curpos = LCDWIDTH * LCDLINES;
			curpos--;
			moveCursor(curpos);
			writeLCDChar(' ');
			if(curpos == 0)
				curpos = LCDWIDTH * LCDLINES;
			curpos--;
			moveCursor(curpos);
			break;
		case SC_MOVE:
			moveCursor(value - 1);			
			break;
		default:;
	}

	return 0;
}

void writeStateMachine()
{
	if((curpos % LCDWIDTH) == 0 && curpos > 0)
		nextLine();
}

void nextLine()
{
	if(linenum == (LCDLINES -1)) 
		LCD_screenCommand(SC_HOME, 0);
	else
	{
		linenum++;
		switch(linenum){
			case 1:
				writeLCDCmd(192);
				break;
			case 2:
				writeLCDCmd(128 + LCDWIDTH);
				break;
			case 3:
				writeLCDCmd(192 + LCDWIDTH);
				break;
			default:;
		}
	}

}

int moveCursor(unsigned char location)
{
	unsigned char c, w;

	if(location <= (LCDWIDTH * LCDLINES))
	{
		c = location / LCDWIDTH;
		w = location % LCDWIDTH;
		switch(c){
			case 0:
				writeLCDCmd(128 + w);
				break;
			case 1:
				writeLCDCmd(192 + w);
				break;
			case 2:
				writeLCDCmd(128 + LCDWIDTH + w);
				break;
			case 3:
				writeLCDCmd(192 + LCDWIDTH + w);
				break;
			default:;
		}

		curpos = location;
		linenum = c;
	}

	return 0;
}

static int initLCD()
{
	//initialize the pins
	initPin(RS);
	initPin(E);
	initPin(D4);
	initPin(D5);
	initPin(D6);
	initPin(D7);

	//set direction
	setPinDirection(RS,OUT);
	setPinDirection(E,OUT);
	setPinDirection(D4,OUT);
	setPinDirection(D5,OUT);
	setPinDirection(D6,OUT);
	setPinDirection(D7,OUT);

	setPinValue(E,OFF);

	//initialize the screen
	pauseNanoSec(1500000);
	initCMD(0x30);
	pauseNanoSec(5000000);
	initCMD(0x30);
	pauseNanoSec(5000000);
	initCMD(0x30);
	pauseNanoSec(5000000);
	initCMD(0x20);

	pauseNanoSec(5000000);
	writeCMD(0x2C);
	pauseNanoSec(5000000);
	writeCMD(0x08);
	pauseNanoSec(5000000);
	writeCMD(0x01);
	pauseNanoSec(2000000);
	writeCMD(0x06);
	pauseNanoSec(5000000);
	writeCMD(0x0E);
	pauseNanoSec(5000000);

	return 0;
}

static void initCMD(unsigned char cmd)
{
	//bring rs low for command
	setPinValue(RS,OFF);
	pauseNanoSec(500000);

	//send the highest nibble only
	setPinValue(E,ON);
	setPinValue(D7,((cmd >> 7) & 1));
	setPinValue(D6,((cmd >> 6) & 1));	
	setPinValue(D5,((cmd >> 5) & 1));	
	setPinValue(D4,((cmd >> 4) & 1));	
	pauseNanoSec(500000);
	setPinValue(E,OFF);
	pauseNanoSec(500000);

}

static int writeChar(unsigned char data)
{
	//bring rs high for character
	pauseNanoSec(500000);
	setPinValue(RS,ON);
	pauseNanoSec(500000);

	//send highest nibble first
	setPinValue(E,ON);
	setPinValue(D7, ((data >> 7) & 1));
	setPinValue(D6, ((data >> 6) & 1));
	setPinValue(D5, ((data >> 5) & 1));
	setPinValue(D4, ((data >> 4) & 1));
	pauseNanoSec(500000);
	setPinValue(E,OFF);
	pauseNanoSec(500000);

	//send the low nibble
	setPinValue(E,ON);
	setPinValue(D7, ((data >> 3) & 1));
	setPinValue(D6, ((data >> 2) & 1));
	setPinValue(D5, ((data >> 1) & 1));
	setPinValue(D4, (data & 1));
	pauseNanoSec(500000);
	setPinValue(E,OFF);
	pauseNanoSec(500000);

	return 0;
}

static int writeCMD(unsigned char cmd)
{
	//bring rs low for command
	setPinValue(RS, OFF);
	pauseNanoSec(500000);

	//send highest nibble first
	setPinValue(E,ON);
	setPinValue(D7, ((cmd >> 7) & 1));
	setPinValue(D6, ((cmd >> 6) & 1));
	setPinValue(D5, ((cmd >> 5) & 1));
	setPinValue(D4, ((cmd >> 4) & 1));
	pauseNanoSec(500000);
	setPinValue(E,OFF);
	pauseNanoSec(500000);

	//send the low nibble
	setPinValue(E,ON);
	setPinValue(D7, ((cmd >> 3) & 1));
	setPinValue(D6, ((cmd >> 2) & 1));
	setPinValue(D5, ((cmd >> 1) & 1));
	setPinValue(D4, (cmd & 1));
	pauseNanoSec(500000);
	setPinValue(E, OFF);
	pauseNanoSec(500000);

	return 0;
}


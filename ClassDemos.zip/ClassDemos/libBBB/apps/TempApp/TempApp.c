/*
//Filename: TempApp.c
//Version : 0.1
//
//Project : Argonne National Lab - Forest
//Author  : Gavin Strunk
//Contact : gavin.strunk@gmail.com
//Date    : 31 July 2013
//
//Description - This program will read in a thermistor on the
//		onboard ADC and use a 5th order polynomial fit
//		to calculate the temperature.
//
//Revision History
//	0.1: Wrote program and tested \GS
*/

/*
Copyright (C) 2013 Gavin Strunk

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include "libBBB.h"
#include <math.h>

//poly correction coef
#define aa	0.00472024866
#define bb	0.565725339
#define cc	0.2129276116

//polynomial coefficients
#define	a	77.3335885175555	
#define b	-186.349544575897
#define c	190.157118132187
#define d	-103.487791924006
#define f	18.8111154863388
#define g	0.0

int main()
{
	int value;
	double temp;
	double temperature;

	//initialize ADC
	initADC(8);

	while(1)
	{
		value = readADC(14, AIN0);
		temp = ((double) value)/1000;
		temp = aa + bb*temp + cc*temp*temp;
		temperature = a + b*temp + c*temp*temp + d*temp*temp*temp + f*temp*temp*temp*temp + g*temp*temp*temp*temp*temp;
		pauseNanoSec(10000000);
		system("clear");
		printf("Temperature Application\n");
		printf("Voltage          = %f\n",temp);
		printf("Temperature in C = %.1f\n", temperature);
		printf("Temperature in F = %.1f\n", ((temperature*1.8)+32));
	}
	return 0;
}

from bbio import *
LED_PIN = GPIO1_81
def setup():
 pinMode(LED_PIN, OUTPUT)
def loop():
 digitalWrite(LED_PIN, HIGH)
 delay(250)
 digitalWrite(LED_PIN, LOW)
 delay(250)
 run(setup, loop)

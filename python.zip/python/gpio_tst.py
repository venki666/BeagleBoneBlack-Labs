import Adafruit_BBIO.GPIO as GPIO
GPIO.cleanup() 
GPIO.setup("P9_14", GPIO.OUT)
GPIO.output("P9_14", GPIO.HIGH)
GPIO.cleanup()
#!/bin/sh
# Blink the USR3 LEDs
# Run the following code forever
while :
do
# Turn on the USR3 LEDs
echo 255 > /sys/class/leds/beaglebone:green:usr3/brightness
sleep 1
echo 0 > /sys/class/leds/beaglebone:green:usr3/brightness
sleep 1
done
